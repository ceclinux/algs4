import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
  private int N;
  private Node first;
  private Node last;

  private class Node {
    Item item;
    Node next;
  }

  // construct an empty randomized queue
  public RandomizedQueue() {
    N = 0;
  }

  // is the queue empty?
  public boolean isEmpty() {
    return N == 0;
  }

  // return the number of items on the queue
  public int size() {
    return N;
  }

  // add the item
  public void enqueue(Item item) {
    if (item == null) {
      throw new NullPointerException();
    }

    Node oldlast = last;
    last = new Node();
    last.item = item;
    last.next = null;
    if (isEmpty()) {
      first = last;
    } else {
      oldlast.next = last;
    }
    N++;
  }

  // remove and return a random item
  public Item dequeue() {
    if (N == 0) {
      throw new NoSuchElementException();
    }

    int ran = StdRandom.uniform(N);
//    System.out.println("deque " + ran);
    Node temp = first;
    Node before = null;
    
    for (int i = 0; i < ran; i++) {
      before = temp;
      temp = temp.next;
    }

    if (ran != 0) {
      before.next = temp.next;
    }else{
      first = temp.next;
    }
    if(ran == N - 1){
      last = before;
    }
    N--;
//    System.out.println("N "+N);
//    System.out.println(first.item);
//    System.out.println(last.item);
    return temp.item;
  }

  // return (but do not remove) a random item
  public Item sample() {
    if (N == 0) {
      throw new NoSuchElementException();
    }
    int ran = StdRandom.uniform(N);
    Node temp = first;
    for (int i = 0; i < ran; i++) {
      temp = temp.next;
    }
    return temp.item;
  }

  // return an independent iterator over items in random order
  public Iterator<Item> iterator() {
    return new RandomizedQueueIterator();
  }

  private class RandomizedQueueIterator implements Iterator<Item> {

    int count = N;
    int number = count -1;
    int[] t;
    private RandomizedQueueIterator(){
       t = new int[N];
      for(int i=0;i<N;i++){
        t[i] = i;
      }
      StdRandom.shuffle(t);
    }
    @Override
    public boolean hasNext() {
      // TODO Auto-generated method stub
      return count != 0;
    }

    @Override
    public Item next() {
      if(!hasNext()){
        throw new NoSuchElementException();
      }
      Node temp = first;
      for (int i = 0; i < t[number]; i++) {
        temp = temp.next;
      }
      number--;
      count--;
      return temp.item;
    }

    @Override
    public void remove() {
      // TODO Auto-generated method stub
      throw new UnsupportedOperationException();
    }
  }

  // unit testing
  public static void main(String[] args) {
    RandomizedQueue<Integer> r = new RandomizedQueue<Integer>();
    r.enqueue(1);
    r.enqueue(2);
    r.enqueue(3);
//    r.enqueue(4);
//    r.dequeue();
//    r.dequeue();
//    r.dequeue();
//    r.enqueue(4);
//    r.dequeue();
//    r.enqueue(4);
//    r.dequeue();
//    r.enqueue(4);
//    r.dequeue();
//    r.enqueue(4);
//    r.dequeue();
//    r.dequeue();
//    r.dequeue();
    
    for (Integer i : r) {
      System.out.println(i);
    }
    
  }
}

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {
  private Item[] a = (Item[]) new Object[1];
  private Integer first;
  private Integer last;
  private int N;

  // construct an empty deque
  public Deque() {
    first = null;
    last = null;
  }

  // is the deque empty?
  public boolean isEmpty() {
    return N == 0;
  }

  // return the number of items on the deque
  public int size() {
    return N;
  }

  // add the item to the front
  public void addFirst(Item item) {
    if (item == null) {
      throw new NullPointerException();
    }
    if(first == null){
      first = 0;
      last = 0;
    }else{
      first = (first - 1 + a.length) % a.length;
    }
    a[first] = item;
//    System.out.println("addFirst" + Arrays.toString(a));
    N++;
    if (N == a.length) {
      resize(2 * N);
    }
  }

  // add the item to the end
  public void addLast(Item item) {
    if (item == null) {
      throw new NullPointerException();
    }
    if(first == null){
      first = 0;
      last = 0;
    }else{
      last = (last + 1) % a.length;
    }
    a[last] = item;
    N++;
    if (N == a.length) {
      resize(2 * N);
    }
  }

  // remove and return the item from the front
  public Item removeFirst() {
    if (N == 0) {
      throw new NoSuchElementException();
    } 
    Item item = a[first];
    a[first] = null;
    first = (first + 1) % a.length;
    N--;
    return item;
  }

  // remove and return the item from the end
  public Item removeLast() {
    if (N == 0) {
      throw new NoSuchElementException();
    }
    Item item = a[last];
    a[last] = null;
    last = (last - 1 + a.length) % a.length;
    N--;
    return item;
  }

  // return an iterator over items in order from front to end
  public Iterator<Item> iterator() {
    return new DequeIterator();
  }

  private class DequeIterator implements Iterator<Item> {
    int count = N;
    Integer f = first;

    @Override
    public boolean hasNext() {
      return count != 0;
    }

    @Override
    public Item next() {
      if(!hasNext()){
        throw new NoSuchElementException();
      }
      count--;

      return a[(f++) % a.length];
    }

    @Override
    public void remove() {
      // TODO Auto-generated method stub
      throw new UnsupportedOperationException();
    }

  }

  private void resize(int max) {
    Item[] b = (Item[]) new Object[max];
    if (first > last) {
      for (int i = 0; i <= last; i++) {
        b[i] = a[i];
      }
      int t;
      int i = a.length - 1;
      for (t = b.length - 1; i >= first; t--,i--) {
        b[t] = a[i];
      }
      first = t + 1;
    } else {
      for (int i = first; i <= last; i++) {
        b[i] = a[i];
      }
    }
    a = b;
//    System.out.println(Arrays.toString(a));
//    System.out.println(first);
//    System.out.println(last);
    
  }

  // unit testing
  public static void main(String[] args) {
    Deque<Integer> testdeque = new Deque<Integer>();
    testdeque.addFirst(new Integer(1));
    testdeque.addFirst(new Integer(2));
    testdeque.addFirst(new Integer(4));
    testdeque.addLast(new Integer(6));
    testdeque.removeFirst();
    // testdeque.addLast(2);
    for (Integer i : testdeque) {
      System.out.println(i);
    }

  }
}
